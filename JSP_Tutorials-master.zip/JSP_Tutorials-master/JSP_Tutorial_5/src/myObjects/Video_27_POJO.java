package myObjects;

public class Video_27_POJO {

	String info = "This is my POJO object";
	
	public String getInfo(){
		return info;
	}
}
